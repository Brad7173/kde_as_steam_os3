#!/bin/bash
#set -x #for debugging
yad --title "About State Flags" \
--window-icon='.steam_utility.png' \
--width='1085' \
--height='500' \
--text-info= - \
--filename=About_State_Flags \
--button=OK:0 \ 
