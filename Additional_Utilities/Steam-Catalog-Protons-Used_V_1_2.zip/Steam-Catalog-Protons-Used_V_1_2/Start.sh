#!/bin/bash
#set -x #for debugging
clear
dir1=~/.steam/root/steamapps/
dir2=~/.steam/root/steamapps/compatdata/
list(){
	for i in $dir2*; do
		appid=$(basename $i)
		Proton(){
			if [[ ! -f $i/config_info ]]; then
				printf "N/A"
			else
				cat $i/config_info | grep -oP '(?<=compatibilitytools.d/).*?(?=/)' | head -n 1
				cat $i/config_info | grep -oP '(?<=common/Proton ).*?(?=/)' | head -n 1
			fi
		}
		printf "%s\t%s\n" "$appid","$(Proton)"
	done
}

list | LC_ALL=C sort -nk1 > protonversionslist
grep -n "name" ~/.steam/root/steamapps/*.acf | sed -e 's/^.*_//;s/\.acf:.:/ /;s/name//;s/"//g;s/\t//g;s/ /,/' | LC_ALL=C sort -nk1 > steamidslist
gawk -i inplace '!/Proton/' steamidslist
gawk -i inplace '!/SDK/' steamidslist
gawk -i inplace '!/Steamworks/' steamidslist
gawk -i inplace '!/Steam Linux Runtime/' steamidslist
AppIDstr=$(cat steamidslist | cut -d ',' -f1)
Protonstr=$(cat protonversionslist | grep "$AppIDstr" > tmp)
SearchParam1=$(cat tmp | cut -d ',' -f1)
GameStr=$(cat steamidslist | grep "$SearchParam1" > tmp2)
tmpstr1=$(cat tmp2 | cut -d ',' -f1)
tmpstr2=$(cat tmp | grep "$tmpstr1" | cut -d ',' -f2 > tmp3)
Combined=$(paste -d, tmp2 tmp3 > Games_Using_Custom_Proton)

rm tmp
rm tmp2
rm tmp3
rm steamidlist
rm protonversionlist

appid=$(cat Games_Using_Custom_Proton | cut -d ',' -f1)
game=$(cat Games_Using_Custom_Proton | cut -d ',' -f2)
proton=$(cat Games_Using_Custom_Proton | cut -d ',' -f3)

yad --window-icon='.steam_utility.png' \
--title "Custom Protons Used" \
--width="990" \
--height="600" \
--button=TXT:'./Text.sh' \
--button=StateFlags:'./StateFlags.sh' \
--button=About:'./About.sh' \
--button=Exit:0 \
--grid-lines=horizontal,vertical \
--list \
--column=AppID "$appid" \
--column=Game "$game" \
--column=Proton  "$proton" \
