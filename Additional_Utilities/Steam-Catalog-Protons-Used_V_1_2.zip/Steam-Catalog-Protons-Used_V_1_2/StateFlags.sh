#!/bin/bash
#set -x #for debugging
clear
	filenames=$(ls ~/.steam/root/steamapps/*.acf | cut -d '/' -f7 > filenames)
	names=$(cat ~/.steam/root/steamapps/*.acf | grep '"name"' | sed 's/	"name"		/<name>/g' | grep -oP '(?<=<name>").*?(?=")' > names)
	appids1=$(cat ~/.steam/root/steamapps/*.acf | grep '"appid"' |  sed 's/	"appid"		/<appid>/g' | grep -oP '(?<=<appid>").*?(?=")' > appids1)
	StateFlags=$(cat ~/.steam/root/steamapps/*.acf | grep '"StateFlags"' |  sed 's/	"StateFlags"		/<StateFlags>/g' | grep -oP '(?<=<StateFlags>").*?(?=")' > StateFlags)
	Description=$(paste -d, filenames appids1 names StateFlags > FileList)
	
filenames=$(cat FileList | cut -d ',' -f1)
appids=$(cat FileList | cut -d ',' -f2)
game=$(cat FileList | cut -d ',' -f3)
stateflags=$(cat FileList | cut -d ',' -f4)

yad --window-icon='.steam_utility.png' \
--title "StateFlags" \
--width="990" \
--height="600" \
--button=About:'./About_State_Flags.sh' \
--button=Exit:0 \
--grid-lines=horizontal,vertical \
--list \
--column=FileName "$filenames" \
--column=AppID "$appids" \
--column=Game "$game" \
--column=StateFlag  "$stateflags" \ 
