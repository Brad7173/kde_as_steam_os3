#!/bin/bash
#set -x #for debugging
yad --title "Custom Protons Used (TXT)" \
--window-icon='.steam_utility.png' \
--width='980' \
--height='500' \
--text-info= - \
--filename=Games_Using_Custom_Proton \
--button=OK:0 \
