#!/bin/bash
#set -x #for debugging
yad --title "About" \
--window-icon='.steam_utility.png' \
--width='980' \
--height='500' \
--text-info= - \
--filename=About \
--button=OK:0 \
