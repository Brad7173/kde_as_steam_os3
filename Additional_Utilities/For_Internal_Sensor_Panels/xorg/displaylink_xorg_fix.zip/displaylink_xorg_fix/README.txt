##################################################################################################
# Displaylink / Nvidia workaround ~ By Katie M. Nelson January 30, 2022
#=================================================================================================
#
#*************************************************************************************************
# To use xorg.conf which offers settings such as "force composition pipeline"
#
# would have to create or copy xorg.conf to /etc/X11/xorg.conf
# ~ would require sudo privilages
# ~ would have to log out
#*************************************************************************************************
# To use displaylink for 7 inch sensor panel
#
# would have to delete xorg.conf ~ /etc/X11/xorg.conf
# ~ would require sudo privilages
# ~ would have to log out
#
##################################################################################################
# Uses mcopy ~ sudo apt install mtools
##################################################################################################
These 2 shellscrips help automate the process simplifying it.
You need to make sure they are executable in the permissions tab or use chmod.
You can use these as a startup script or however needed.
I can't guarantee this will work for every linux os but should for Ubuntu/Kubuntu distros.
Mcopy is needed for this to work and for your os there may be other install methods.
