#! /bin/sh
##################################################################################################
# Displaylink / Nvidia workaround ~ By Katie M. Nelson January 30, 2022
#=================================================================================================
#
#*************************************************************************************************
# To use xorg.conf which offers settings such as "force composition pipeline"
#
# would have to create or copy xorg.conf to /etc/X11/xorg.conf
# ~ would require sudo privilages
# ~ would have to log out
#*************************************************************************************************
# To use displaylink for 7 inch sensor panel
#
# would have to delete xorg.conf ~ /etc/X11/xorg.conf
# ~ would require sudo privilages
# ~ would have to log out
#
##################################################################################################
# Uses mcopy ~ sudo apt install mtools
##################################################################################################
if [ -d "/etc/X11/Backup/" ] #check if backup directory exist
then
    FILE=/etc/X11/Backup/xorg.conf
        if [ -f "$FILE" ]; then # directory exist...check if file exist
            sudo mcopy /etc/X11/Backup/xorg.conf /etc/X11/xorg.conf # restore xorg.conf
            echo "xorg.conf restored to /etc/X11/" # Notify user!
            $SHELL
        else
            echo "$FILE does not exist." # action if xorg.conf doesn't exit
            $SHELL
        fi
else # if /etc/X11/Backup/ directory doesn't exit
            sudo mkdir /etc/X11/Backup # action if directory doesn't exist
            echo "/etc/X11/Backup/ directory created. You have no backed up xorg.conf to restore." # Notify user!
            $SHELL
fi
$SHELL


















#if [ -d "/etx/x11/Backup/" ]
#then
#    sudo sudo mcopy /etx/x11/Backup/xorg.conf /etx/x11/xorg.conf
#else
#    sudo mkdir /etx/x11/Backup
#fi

